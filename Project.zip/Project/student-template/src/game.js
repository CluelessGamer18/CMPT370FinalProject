class Game {
  constructor(state) {
    this.state = state;
    this.spawnedObjects = [];
    this.collidableObjects = [];

    // Set these values here so we don't have to create them every time we do anything (this is what solved a lot of our lag problems)
    this.tempLocalOffset = vec3.fromValues(0, 0.25, 0);
    this.tempWorldOffset = vec3.create();
    this.tempForward = vec3.create();
    this.tempRotationMat3 = mat3.create();
    this.templocalMove = vec3.create();
    this.tempWorldMove = vec3.create();
    this.tempOriginalPosition = vec3.create();
  }

  // example - we can add our own custom method to our game and call it using 'this.customMethod()'
  customMethod() {
    console.log("Custom method!");
  }

  // example - create a collider on our object with various fields we might need (you will likely need to add/remove/edit how this works)
  createSphereCollider(object, radius, onCollide = null) {
    object.collider = {
      type: "SPHERE",
      radius: radius,
      onCollide: onCollide ? onCollide: (otherObject) => {
        // Check to see if the collided object is our NPC, if it is have him display a nice message
        if (otherObject.name === "NPC"){
          const msg = document.getElementById("collisionMessage");
          msg.innerText = "Hello Player!";
          msg.style.display = "block";

          setTimeout(() =>{
            msg.style.display = "none";
          }, 3000);

          setTimeout(() =>{
            msg.innerText = "Good luck on your journey!";
            msg.style.display = "block";
          }, 3000);

          setTimeout(() =>{
            msg.style.display = "none";
          }, 5000);
        }
      }
    };
    this.collidableObjects.push(object);
  }

  // Create a box collider to detect hitboxes possibly
  // Using a halfsize for each coordinate (xyz) allows for simpler math and faster compution times (no division during actual computions)
  createBoxCollider(object, width, height, depth, onCollide = null) {
    object.collider = {
      type: "BOX",
      halfsize: [
        width / 2,
        height / 2,
        depth / 2
      ],
      onCollide: onCollide ? onCollide: (otherObject) => {
        // Check to see if the collided object is our NPC, if it is have him display a nice message
        if (otherObject.name === "NPC"){
          const msg = document.getElementById("collisionMessage");
          msg.innerText = "Hello Player!";
          msg.style.display = "block";

          setTimeout(() =>{
            msg.style.display = "none";
          }, 3000);

          setTimeout(() =>{
            msg.innerText = "Good luck on your journey!";
            msg.style.display = "block";
          }, 3000);

          setTimeout(() =>{
            msg.style.display = "none";
          }, 5000);
        }
      }
    };
    
    this.collidableObjects.push(object);
  }

  // Collision logic for two box colliders colliding
  checkBoxvsBox(objA, objB){
    const aPos = objA.model.position; // Box A's position
    const bPos = objB.model.position; // Box B's position

    const aHalfsize = objA.collider.halfsize; // Box A's halfsize
    const bHalfsize = objB.collider.halfsize; // Box B's halfsize

    // Return true if collided, false if not
    return (
      Math.abs(aPos[0] - bPos[0]) < (aHalfsize[0] + bHalfsize[0]) && Math.abs(aPos[1] - bPos[1]) < (aHalfsize[1] + bHalfsize[1]) && Math.abs(aPos[2] - bPos[2]) < (aHalfsize[2] + bHalfsize[2])
    );
  }

  // Collision logic for two sphere colliders colliding
  checkSpherevsSphere(objA, objB) {
    let dx = objB.model.position[0] - objA.model.position[0]; // X distance from Sphere A to Sphere B
    let dy = objB.model.position[1] - objA.model.position[1]; // Y distance from Sphere A to Sphere B
    let dz = objB.model.position[2] - objA.model.position[2]; // Z distance from Sphere A to Sphere B
    let distSquared = (dx*dx) + (dy*dy) + (dz*dz); // Total Distance
    let radSquare = objA.collider.radius + objB.collider.radius; // Add together both Sphere's Radii

    // Return squared distance to limit use or sqrt functions
    return distSquared < (radSquare * radSquare);
  }

  // Collision logic for a sphere colliding with a box and vice versa
  checkSpherevsBox(sphereObj, boxObj){
    const sPos = sphereObj.model.position; // Sphere object position
    const bPos = boxObj.model.position; // Box object position
    const bHalf = boxObj.collider.halfsize; // Halfsize of box object
    const rad = sphereObj.collider.radius; // Radius of sphere object

    // Find the closest spot on the box to the sphere's center
    let closestX = Math.max(bPos[0] - bHalf[0], Math.min(sPos[0], bPos[0] + bHalf[0]));
    let closestY = Math.max(bPos[1] - bHalf[1], Math.min(sPos[1], bPos[1] + bHalf[1]));
    let closestZ = Math.max(bPos[2] - bHalf[2], Math.min(sPos[2], bPos[2] + bHalf[2]));

    // Distance from the sphere's center to the closest point on the box
    let dx = closestX - sPos[0];
    let dy = closestY - sPos[1];
    let dz = closestZ - sPos[2];

    // Total distance
    let distanceSq = (dx*dx) + (dy*dy) + (dz*dz);

    // Return squared distance to limit use or sqrt functions
    return distanceSq < (rad * rad);
  }

  // example - function to check if an object is colliding with collidable objects
  checkCollision(object) {
    let collided = false;
    // loop over all the other collidable objects 
    this.collidableObjects.forEach(otherObject => {
      // Use this helper function
      if (this.checkCollisionBetween(object, otherObject)){
        collided = true;
        object.collider.onCollide(otherObject);
      }
      
    });
    return collided; // No collision found
  }

  // runs once on startup after the scene loads the objects
  async onStart() {
    console.log("On start");

    // this just prevents the context menu from popping up when you right click
    document.addEventListener("contextmenu", (e) => {
      e.preventDefault();
    }, false);

    // Set the objects
    this.cube = getObject(this.state, "Player"); // Character object
    // Platforms
    this.platform1 = getObject(this.state, "platform001");
    this.platform2 = getObject(this.state, "platform002");
    this.platform3 = getObject(this.state, "platform003");
    this.platform4 = getObject(this.state, "platform004");
    this.platform5 = getObject(this.state, "platform005");
    this.platform6 = getObject(this.state, "platform006");
    this.platform7 = getObject(this.state, "platform007");
    this.platform8 = getObject(this.state, "platform008");
    this.platform9 = getObject(this.state, "platform009");
    this.platform10 = getObject(this.state, "platform010");
    this.platform11 = getObject(this.state, "platform011");
    this.platform12 = getObject(this.state, "platform012");
    this.platform13 = getObject(this.state, "platform013");
    this.platform14 = getObject(this.state, "platform014");
    this.platform15 = getObject(this.state, "platform015");
    this.platform16 = getObject(this.state, "platform016");
    this.platform17 = getObject(this.state, "platform017");
    this.platform18 = getObject(this.state, "platform018");
    this.platform19 = getObject(this.state, "platform019");
    this.platform20 = getObject(this.state, "platform020");
    this.platform21 = getObject(this.state, "platform021");
    this.platform22 = getObject(this.state, "platform022");
    this.platform23 = getObject(this.state, "platform023");
    this.platform24 = getObject(this.state, "platform024");
    this.platform25 = getObject(this.state, "platform025");
    this.platform26 = getObject(this.state, "platform026");
    this.platform27 = getObject(this.state, "platform027");
    this.platform28 = getObject(this.state, "platform028");
    this.platform29 = getObject(this.state, "platform029");
    this.platform30 = getObject(this.state, "platform030");

    // Ground and Walls
    this.plane = getObject(this.state, "Ground"); // Ground
    this.plane1 = getObject(this.state, "roof"); // Roof
    this.wall1 = getObject(this.state, "wall1");
    this.wall2 = getObject(this.state, "wall2");
    this.wall3 = getObject(this.state, "wall3");
    this.wall4 = getObject(this.state, "wall4");
    // NPCs
    this.custom1 = getObject(this.state, "enemy");

    // Create the colliders
    // Player
    this.createBoxCollider(this.cube, this.cube.model.scale[0], this.cube.model.scale[1], this.cube.model.scale[2]); 
    // Walls and Ground
    this.createBoxCollider(this.plane, this.plane.model.scale[0]*0.5, this.plane.model.scale[1]*0.5, this.plane.model.scale[2]*0.5);
    this.createBoxCollider(this.plane1, this.plane.model.scale[0]*0.5, this.plane1.model.scale[1]*0.5, this.plane1.model.scale[2]*0.5);
    

    this.createBoxCollider(this.wall1, this.wall1.model.scale[0]*0.5, this.wall1.model.scale[1]*0.5, this.wall1.model.scale[2]*0.5);
    this.createBoxCollider(this.wall2, this.wall2.model.scale[0]*0.5, this.wall2.model.scale[1]*0.5, this.wall2.model.scale[2]*0.5);
    this.createBoxCollider(this.wall3, this.wall3.model.scale[0]*0.5, this.wall3.model.scale[1]*0.5, this.wall3.model.scale[2]*0.5);
    this.createBoxCollider(this.wall4, this.wall4.model.scale[0]*0.5, this.wall4.model.scale[1]*0.5, this.wall4.model.scale[2]*0.5);
    // Platforms
    this.createBoxCollider(this.platform1, this.platform1.model.scale[0]*0.5, this.platform1.model.scale[1]*0.5, this.platform1.model.scale[2]*0.5);
    this.createBoxCollider(this.platform2, this.platform2.model.scale[0]*0.5, this.platform2.model.scale[1]*0.5, this.platform2.model.scale[2]*0.5);
    this.createBoxCollider(this.platform3, this.platform3.model.scale[0]*0.5, this.platform3.model.scale[1]*0.5, this.platform3.model.scale[2]*0.5);
    this.createBoxCollider(this.platform4, this.platform4.model.scale[0]*0.5, this.platform4.model.scale[1]*0.5, this.platform4.model.scale[2]*0.5);
    this.createBoxCollider(this.platform5, this.platform5.model.scale[0]*0.5, this.platform5.model.scale[1]*0.5, this.platform5.model.scale[2]*0.5);
    this.createBoxCollider(this.platform6, this.platform6.model.scale[0]*0.5, this.platform6.model.scale[1]*0.5, this.platform6.model.scale[2]*0.5);
    this.createBoxCollider(this.platform7, this.platform7.model.scale[0]*0.5, this.platform7.model.scale[1]*0.5, this.platform7.model.scale[2]*0.5);
    this.createBoxCollider(this.platform8, this.platform8.model.scale[0]*0.5, this.platform8.model.scale[1]*0.5, this.platform8.model.scale[2]*0.5);
    this.createBoxCollider(this.platform9, this.platform9.model.scale[0]*0.5, this.platform9.model.scale[1]*0.5, this.platform9.model.scale[2]*0.5);
    this.createBoxCollider(this.platform10, this.platform10.model.scale[0]*0.5, this.platform10.model.scale[1]*0.5, this.platform10.model.scale[2]*0.5);
    this.createBoxCollider(this.platform11, this.platform11.model.scale[0]*0.5, this.platform11.model.scale[1]*0.5, this.platform11.model.scale[2]*0.5);
    this.createBoxCollider(this.platform12, this.platform11.model.scale[0]*0.5, this.platform12.model.scale[1]*0.5, this.platform12.model.scale[2]*0.5);
    this.createBoxCollider(this.platform13, this.platform11.model.scale[0]*0.5, this.platform13.model.scale[1]*0.5, this.platform13.model.scale[2]*0.5);
    this.createBoxCollider(this.platform14, this.platform11.model.scale[0]*0.5, this.platform14.model.scale[1]*0.5, this.platform14.model.scale[2]*0.5);
    this.createBoxCollider(this.platform15, this.platform11.model.scale[0]*0.5, this.platform15.model.scale[1]*0.5, this.platform15.model.scale[2]*0.5);
    this.createBoxCollider(this.platform16, this.platform11.model.scale[0]*0.5, this.platform16.model.scale[1]*0.5, this.platform16.model.scale[2]*0.5);
    this.createBoxCollider(this.platform17, this.platform11.model.scale[0]*0.5, this.platform17.model.scale[1]*0.5, this.platform17.model.scale[2]*0.5);
    this.createBoxCollider(this.platform18, this.platform11.model.scale[0]*0.5, this.platform18.model.scale[1]*0.5, this.platform18.model.scale[2]*0.5);
    this.createBoxCollider(this.platform19, this.platform11.model.scale[0]*0.5, this.platform19.model.scale[1]*0.5, this.platform19.model.scale[2]*0.5);
    this.createBoxCollider(this.platform20, this.platform11.model.scale[0]*0.5, this.platform20.model.scale[1]*0.5, this.platform20.model.scale[2]*0.5);
    this.createBoxCollider(this.platform21, this.platform11.model.scale[0]*0.5, this.platform21.model.scale[1]*0.5, this.platform21.model.scale[2]*0.5);
    this.createBoxCollider(this.platform22, this.platform11.model.scale[0]*0.5, this.platform22.model.scale[1]*0.5, this.platform22.model.scale[2]*0.5);
    this.createBoxCollider(this.platform23, this.platform11.model.scale[0]*0.5, this.platform23.model.scale[1]*0.5, this.platform23.model.scale[2]*0.5);
    this.createBoxCollider(this.platform24, this.platform11.model.scale[0]*0.5, this.platform24.model.scale[1]*0.5, this.platform24.model.scale[2]*0.5);
    this.createBoxCollider(this.platform25, this.platform11.model.scale[0]*0.5, this.platform25.model.scale[1]*0.5, this.platform25.model.scale[2]*0.5);
    this.createBoxCollider(this.platform26, this.platform11.model.scale[0]*0.5, this.platform26.model.scale[1]*0.5, this.platform26.model.scale[2]*0.5);
    this.createBoxCollider(this.platform27, this.platform11.model.scale[0]*0.5, this.platform27.model.scale[1]*0.5, this.platform27.model.scale[2]*0.5);
    this.createBoxCollider(this.platform28, this.platform11.model.scale[0]*0.5, this.platform28.model.scale[1]*0.5, this.platform28.model.scale[2]*0.5);
    this.createBoxCollider(this.platform29, this.platform11.model.scale[0]*0.5, this.platform29.model.scale[1]*0.5, this.platform29.model.scale[2]*0.5);
    this.createBoxCollider(this.platform30, this.platform11.model.scale[0]*0.5, this.platform30.model.scale[1]*0.5, this.platform30.model.scale[2]*0.5);

    // NPCs
    this.createBoxCollider(this.custom1, this.custom1.model.scale[0], this.custom1.model.scale[1], this.custom1.model.scale[1]);

    // Listen for key presses and add them to a list to keep track of for another function below
    document.addEventListener("keydown", (e) => {
      this.cube.pressedKeys[e.key] = true;
    });

    // Once user lets go of those keys remove them from the list to stop using them
    document.addEventListener("keyup", (e) =>{
      this.cube.pressedKeys[e.key] = false;
      
    });

    document.addEventListener("keypress", (e) => {
      e.preventDefault();

      switch (e.key) {
        // Test if the spacebar is pressed
        case " ":
          if (this.cube.firstPersonToggle){
            if (!this.cube.isJumping){
              this.cube.velocity[1] = this.cube.jumpSpeed; // Assign a preset jumpspeed to the object
              this.cube.isJumping = true; // Set the isJumping flag to true
            }
          }
          break;

        case "m": // This sets a toggle for the first person camera angle, it also locks and hides the cursor while active to allow for smooth movement
          if (this.cube.firstPersonToggle == false){
            this.cube.firstPersonToggle = true; // Toggle on our first person view
            document.body.requestPointerLock(); // 'Locks' cursor, allows for tracking of motion on a wider range
            this.cube.material.alpha = 0.0; // Sets our objects alpha value to 0 so we dont see ourselves while we move
          } else {
            this.cube.firstPersonToggle = false; // Toggle off our first person view
            document.exitPointerLock(); // Unlock our cursor
            this.cube.material.alpha = 1.0; // Reset alpha value for our character (in this instance we are fully opaque)
          }

        default:
          break;
      }
    });

    // Music Player for our Background Music ;)
    document.addEventListener("click", () => {
      startMusic();
    }, {once: true});

    const bgMusic = document.getElementById("bgMusic");
    function startMusic() {
      bgMusic.volume = 0.01;
      bgMusic.play();
    }
    let threshold = 1; // Minimum pixels that the mouse has to move to rotate

    // Allows for cube to rotate around in the direction of the mouse (only around y for now, x and z are a pain and might be too complicated for the remainin scope)
    document.addEventListener("mousemove", (e) => {
      e.preventDefault();
      if (this.cube.firstPersonToggle){
        if (Math.abs(e.movementX) < threshold && Math.abs(e.movementY) < threshold) return;
        
        // Adds mouse movements to a set value within the RenderObject Cube file
        this.cube.accumulatedX += e.movementX;
        this.cube.accumulatedY += e.movementY;
      }
    });

  }

  // New Movement Option
  updateMovement(keys) {
      let moveX = 0; // Set temp value for movement
      let moveY = 0; // Set temp value for Y movement (camera only)
      let moveZ = 0; // Set temp value for movement
      let rotationSpeed = 1; // Camera Rotation Speed (camera only)

      // Determine what key was pressed and what values to set
      if (keys['w']) moveX += 1;
      if (keys['s']) moveX -= 1;
      if (keys['a']) moveZ -= 1;
      if (keys['d']) moveZ += 1;
      if (keys['ArrowUp']) moveY += 1;
      if (keys['ArrowDown']) moveY -= 1;

      // No movement detected, return out of the function because we don't need to modify the values
      // if (moveX === 0 && moveZ === 0 && moveY === 0) return;

      if (this.cube.firstPersonToggle){
        // This is our temporary movement value, we will use it later
        this.templocalMove[0] = moveX;
        this.templocalMove[1] = 0;
        this.templocalMove[2] = moveZ;

        vec3.normalize(this.templocalMove, this.templocalMove); // Normalize direction Values

        const speed = 0.05; // Set a scaleable speed value to set movement to be the same speed
        // Scale the movement vector by the speed
        vec3.scale(this.templocalMove, this.templocalMove, speed);

        // Get the cube's rotation matrix, but only the rotations (we dont need the translations / scale)
        mat3.fromMat4(this.tempRotationMat3, this.cube.model.rotation);
        // Set the worldMove value based on the localMove and the rotation matrix
        vec3.transformMat3(this.tempWorldMove, this.templocalMove, this.tempRotationMat3);

        // Copy the current position before moving in case of collision
        vec3.copy(this.tempOriginalPosition, this.cube.model.position);
        vec3.add(this.cube.model.position, this.cube.model.position, this.tempWorldMove);

        // If there is a collision go back to the previous value
        if(this.checkCollision(this.cube)){
          vec3.copy(this.cube.model.position, this.tempOriginalPosition);
        }

      } else { // Use WASD, Shift, Control, and the left and right arrow keys to move the camera 
        const localMove = vec3.fromValues(moveX, moveY, moveZ); // Get what directions we need to move
        vec3.normalize(localMove, localMove);

        const speed = 0.05; // Set a constant speed to move in all directions
        vec3.scale(localMove, localMove, speed);

        const forward = state.camera.front; // Get which direction the camera is facing
        vec3.normalize(forward, forward);

        const right = vec3.fromValues(forward[2], 0, -forward[0]); // Get what direction is to the right

        const worldMoveCamera = vec3.create(); // Create the worldMovement vector
        vec3.scale(worldMoveCamera, forward, localMove[0]); // Adjust by the directions that we are moving
        const rightMove = vec3.create();
        vec3.scale(rightMove, right, -localMove[2]); // Scale the direction 
        const upMove = vec3.fromValues(0, localMove[1], 0); // Include up and down

        // Add XYZ coords to the world camera to tell us which direction it is moving
        vec3.add(worldMoveCamera, worldMoveCamera, rightMove);
        vec3.add(worldMoveCamera, worldMoveCamera, upMove);

        // Adjust camera by the world values
        state.camera.position[0] += worldMoveCamera[0];
        state.camera.position[1] += worldMoveCamera[1];
        state.camera.position[2] += worldMoveCamera[2];

        // Use the arrow keys to update the rotation values for the cam to allow for horizontal rotations
        if (keys['ArrowRight']){
          const rotationMat = mat4.create();
          mat4.rotateY(rotationMat, rotationMat, (-rotationSpeed*Math.PI / 180)); // Rotate around Y
          vec3.transformMat4(state.camera.front, state.camera.front, rotationMat);
        }
        
        if (keys['ArrowLeft']){
          const rotationMat = mat4.create();
          mat4.rotateY(rotationMat, rotationMat, (rotationSpeed*Math.PI / 180)); // Rotate around Y
          vec3.transformMat4(state.camera.front, state.camera.front, rotationMat);
        }

      }

    }

    // Uses the set values given to the cube to rotate around the Y axis, giving us horizontal vision (Vertical may be too hard for the scope right now)
    updateFirstPerson() {
      if (this.cube.firstPersonToggle) {
        let rotationY = this.cube.accumulatedX * this.cube.mouseSpeedY * this.cube.smoothing;
        // let smoothedY = rotationY * this.cube.smoothed;

        this.cube.rotate('y', rotationY);

        this.cube.accumulatedX *= (1- this.cube.smoothing * 0.8);
      }
    }

  // Function to get the height of a collided with object
  getCollisionHeight(objA){
    for (let obj of this.collidableObjects){
      if (this.checkCollisionBetween(objA, obj)){
        return obj.model.position[1] + obj.collider.halfsize[1]; // return the sum of the collided objects height and its current position at y
      }
    }
    return null;
  }
  
  // Helper function for determining what collider type is hitting each other, returns true or false depending on if the objects collide
  checkCollisionBetween(objA, objB){
    if (objA.name === objB.name) return false;

    if (objA.collider.type === "SPHERE" && objB.collider.type === "SPHERE"){
      return this.checkSpherevsSphere(objA, objB);
    }

    if (objA.collider.type === "BOX" && objB.collider.type === "BOX"){
      return this.checkBoxvsBox(objA, objB);
    }

    if (objA.collider.type === "SPHERE" && objB.collider.type === "BOX"){
      return this.checkSpherevsBox(objA, objB);
    }

    if (objA.collider.type === "BOX" && objB.collider.type === "SPHERE"){
      return this.checkSpherevsBox(objA, objB);
    }

    return false;
  }


  updateCamera(){
    if (this.cube.firstPersonToggle){
      vec3.transformMat4(this.tempWorldOffset, this.tempLocalOffset, this.cube.modelMatrix); // Add the created localOffset and the modleMatrix together to get the world offset
      // Set new camera position based on the above values
      const pos = this.cube.model.position;
      state.camera.position[0] = pos[0] + this.tempWorldOffset[0];
      state.camera.position[1] = pos[1] + this.tempWorldOffset[1];
      state.camera.position[2] = pos[2] + this.tempWorldOffset[2];
      let rot = this.cube.model.rotation; // Get the rotation matrix from the cube
      // Create a forwards vector to determine which way the cube is facing
      this.tempForward[0] = rot[0];
      this.tempForward[1] = rot[1];
      this.tempForward[2] = rot[2];
      vec3.normalize(this.tempForward, this.tempForward); // Normalize that value
      state.camera.front = this.tempForward // Set that value to direct the camera's front in the same direction
    };

  }

  evilMovement(object){
      // check if player has reached min height
      if (object.model.position[1] < 1){
        return
      }
        // enemy max speed
        let maxVelocityX = 0.01;
        let maxVelocityY = 0.01;

        // check which direction to move towards player
        let evilMoveDirectionX = object.model.position[0] - this.custom1.model.position[0];
        let evilMoveDirectionY = object.model.position[1] - this.custom1.model.position[1];

        if (evilMoveDirectionX > 0){
          // no change number is already positive
        } else {
          maxVelocityX = maxVelocityX * -1
        }

        if (evilMoveDirectionY > 0){
          // no change number is already positive
        } else {
          maxVelocityY = maxVelocityY * -1
        }
        let tempMaxVelocityX = maxVelocityX;
        let tempminVelocityY = maxVelocityY;

        const msg = document.getElementById("collisionMessage");

        // check if x & y are with (X) distance to begin attack
        // upper and lower bounds for ranged attack
        let xRangeMax = object.model.position[0] +1;
        let xRangeMin = object.model.position[0] -1;

        let yRangeMax = object.model.position[1] +1;
        let yRangeMin = object.model.position[1] -1;        

        if (xRangeMax > this.custom1.model.position[0] && this.custom1.model.position[0] > xRangeMin && yRangeMax > this.custom1.model.position[1] && this.custom1.model.position[1] > yRangeMin){
          // within range, slow speed, charge attack


          if (this.custom1.chargeLevel < 200){
            msg.innerText = 'Enemy Charge Level: ' +this.custom1.chargeLevel+'/200';
          msg.style.display = "block";
          this.custom1.chargeLevel += 1;
          } else {
            msg.innerText = "YOU DIED"
            setTimeout(() => {
              object.model.position = vec3.fromValues(0.0,0.25,0.0);
            }, 300);
          }

        } else {
          msg.innerText = 'Enemy Charge Level: 0/200';
            msg.style.display = "block";
            this.custom1.chargeLevel = 0
        }


        const evilLocalMove = vec3.fromValues(maxVelocityX,0.0,maxVelocityY);
        vec3.normalize(evilLocalMove,evilLocalMove);

        if (this.custom1.model.position[0] != this.cube.model.position[0]){
        this.custom1.model.position[0] += maxVelocityX;
        }

        if (this.custom1.model.position[1] != this.cube.model.position[1]){
        this.custom1.model.position[1] += maxVelocityY;
        }
      }

  // Runs once every frame non stop after the scene loads
  onUpdate(deltaTime) {
    // Apply gravity if not grounded or if jumping
    if (!this.cube.isGrounded || this.cube.isJumping) {
      this.cube.velocity[1] += this.cube.gravity * deltaTime;
    }

    // Move cube
    this.cube.model.position[1] += this.cube.velocity[1] * deltaTime;

    // Resolve collisions AFTER movement
    const hitHeight = this.getCollisionHeight(this.cube);

    if (hitHeight != null) {
      const expectedY = hitHeight + this.cube.collider.halfsize[1];

    // Only grounded if cube is AT or BELOW the surface
      if (this.cube.model.position[1] <= expectedY) {

        // LAND
        this.cube.model.position[1] = expectedY;
        this.cube.velocity[1] = 0;
        this.cube.isJumping = false;
        this.cube.isGrounded = true;

      } else {
        // Up in the air (jumping, falling, etc)
        this.cube.isGrounded = false;
        
      }

    } else {
      // No ground under us at all
      this.cube.isGrounded = false;
      
    }


    // Move NPC along Z axis between 2 certain values
    //this.custom.model.position[2] += this.custom.direction * 0.5 * deltaTime;

    // If it hits a max value swap its direction
    

    this.updateMovement(this.cube.pressedKeys); // Call movement for our object using the pressedKeys list that has been added to
    this.updateFirstPerson();
    this.updateCamera();
    this.checkCollision(this.cube); // Call collision checks on our object
    this.evilMovement(this.cube);
  }
}
